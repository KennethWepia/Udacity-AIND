rows = 'ABCDEFGHI'
cols = '123456789'

def cross(a, b):
      return [s+t for s in a for t in b]
  
boxes = cross(rows, cols)
boxes = ['A1', 'A2', 'A3', 'A4', 'A5', 'A6', 'A7', 'A8', 'A9',
     'B1', 'B2', 'B3', 'B4', 'B5', 'B6', 'B7', 'B8', 'B9',
     'C1', 'C2', 'C3', 'C4', 'C5', 'C6', 'C7', 'C8', 'C9',
     'D1', 'D2', 'D3', 'D4', 'D5', 'D6', 'D7', 'D8', 'D9',
     'E1', 'E2', 'E3', 'E4', 'E5', 'E6', 'E7', 'E8', 'E9',
     'F1', 'F2', 'F3', 'F4', 'F5', 'F6', 'F7', 'F8', 'F9',
     'G1', 'G2', 'G3', 'G4', 'G5', 'G6', 'G7', 'G8', 'G9',
     'H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'H7', 'H8', 'H9',
     'I1', 'I2', 'I3', 'I4', 'I5', 'I6', 'I7', 'I8', 'I9'] 

row_units = [cross(r, cols) for r in rows]
column_units = [cross(rows, c) for c in cols]
square_units = [cross(rs, cs) for rs in ('ABC','DEF','GHI') for cs in ('123','456','789')]
unitlist = row_units + column_units + square_units


def calculateDiagonalUnits(inverse):
    increment = 0
    diagonal_units = []
    columns = cols
    if inverse:
        columns = cols[::-1]

    for rw in rows:
        dunit = (rows[increment] + columns[increment])
        diagonal_units.insert(increment,dunit)
        increment = increment + 1
    return diagonal_units


diagonal_units = [calculateDiagonalUnits(False), calculateDiagonalUnits(True)]
unitlist = unitlist + diagonal_units
print(unitlist)


units = dict((s, [u for u in unitlist if s in u]) for s in boxes)
peers = dict((s, set(sum(units[s],[]))-set([s])) for s in boxes)


def naked_twins(values):
    
    
    twinBoxes = [boxName for boxName in values.keys() if len(values[boxName]) == 2]
    
    for boxName in twinBoxes:
       
        possibleOptions = values[boxName]
        
        for peer in peers[boxName]:
            if (values[peer] == possibleOptions):
                print("Found nakedTwin")
                print("possibleOption is: " + boxName + " with value: " + possibleOptions + " and his nakedTwin is: " + peer + ": " + values[peer])

                
                sharedPeers = [nakedOne for nakedOne in peers[boxName] if nakedOne in peers[peer]]
                print("Shared peers are: " + str(sharedPeers))
                for sharedPeerBox in sharedPeers:
                    print("The values of sharedPeer: " + sharedPeerBox + " is: " + values[sharedPeerBox])
                    for possibleOption in possibleOptions:
                        values[sharedPeerBox] = values[sharedPeerBox].replace(possibleOption, '')
                    print("The values of sharedPeer: " + sharedPeerBox + " is: " + values[sharedPeerBox])


    
    return values
    


def eliminate(values):
    
   
    solved_values = [box for box in values.keys() if len(values[box]) == 1]
    for box in solved_values:
        digit = values[box]
        for peer in peers[box]:
            values[peer] = values[peer].replace(digit,'')
    return values
   


def only_choice(values):
    
    
    for unit in unitlist:
        for digit in '123456789':
            dplaces = [box for box in unit if digit in values[box]]
            if len(dplaces) == 1:
                values[dplaces[0]] = digit
    return values
    


def reduce_puzzle(values):
    
    
    
    stalled = False
    while not stalled:
        solved_values_before = len([box for box in values.keys() if len(values[box]) == 1])
        values = eliminate(values)
        values = only_choice(values)
        
        values = naked_twins(values)

        solved_values_after = len([box for box in values.keys() if len(values[box]) == 1])
        
        stalled = solved_values_before == solved_values_after
       
        if len([box for box in values.keys() if len(values[box]) == 0]):
            return False
    return values


def search(values):

   
    values = reduce_puzzle(values)
    if values is False:
        return False 
    if all(len(values[s]) == 1 for s in boxes): 
        return values 
  
    n,s = min((len(values[s]), s) for s in boxes if len(values[s]) > 1)
    
    for value in values[s]:
        new_sudoku = values.copy()
        new_sudoku[s] = value
        attempt = search(new_sudoku)
        if attempt:
            return attempt
   


def solve(grid):
    
    grid('2.............62....1....7...6..8...3...9...7...6..4...4....8....52.............3')
    
    values = grid2values(grid)
    values = search(values)
    return values


if __name__ == "__main__":
   
    diag_sudoku_grid = '9...........7.9...2.....8......7...3..36287..1...9......6.....5...5.4...........1'

    display(grid2values(diag_sudoku_grid))
    result = solve(diag_sudoku_grid)
    display(result)

    try:
        import PySudoku
        PySudoku.play(grid2values(diag_sudoku_grid), result, history)

    except SystemExit:
        pass
    except:
        print('We could not visualize your board due to a pygame issue. Not a problem! It is not a requirement.')